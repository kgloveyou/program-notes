export const config = {
  baseUrl: "http://localhost:4000",
};
